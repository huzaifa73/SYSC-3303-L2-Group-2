package pack;

/**
 * @author Blake, Hovish
 *
 */
public enum MotorState {
	UP, DOWN, STOPPED

}
