package pack1;
import java.io.File;
import java.util.*;



/**
 * Class to run the elevator system
 * 
 * @author
 * @version 1.00
 */
public class ElevatorSystem {
	public static void main(String[] args) {
		
		File inputFile = new File(
				"C:\\Users\\camma\\Documents\\Current Work\\WINTER 2021\\SYSC 3303\\Project\\GITHUB_REPO\\Iteration1Elevator\\src\\pack1\\FloorInputFile");
		
		//Create threads
		Thread floorSubsystem, elevator, scheduler;
		Scheduler schedulerObj = new Scheduler();
		FloorSubsystem floorSubsystemObj = new FloorSubsystem(schedulerObj, inputFile);
		Elevator elevatorObj = new Elevator(schedulerObj);
		
		schedulerObj.setup(floorSubsystemObj, elevatorObj);
		
		scheduler = new Thread(schedulerObj, "scheduler");
		floorSubsystem = new Thread(floorSubsystemObj, "FloorThread");
		elevator = new Thread(new Elevator(schedulerObj),"elevator");

		
		
		//Start threads
		floorSubsystem.start();
		elevator.start();
		scheduler.start();

	}
}

